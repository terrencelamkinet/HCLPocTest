# CRM Detail Pages — Source Code 包（2026-09-06）

> 用途：大幅度調整 reference。所有 active detail pages（App.tsx route 確認）。

## 架構
- **App.tsx routes** → 每個 module 嘅 DetailPage 組件
- Detail pages 用共用 layout：`NexusDetailPageV2`（desktop 兩欄：header + tab content）/ `DetailDrawerContent`（drawer 用）
- Tabs 內容喺 `*DetailTabs.tsx`（contacts/companies）+ sub-components（calendar）

## File 清單（13 個 active files，3,790 行）

| File | 角色 | 行數 |
|---|---|---|
| `modules/contacts/ContactDetailPage.tsx` | 聯絡人 Detail（route /contacts/:id） | 179 |
| `modules/contacts/ContactDetailTabs.tsx` | 聯絡人 tabs 內容（概覽/活動/任務…） | 503 |
| `modules/companies/CompaniesDetailPage.tsx` | 公司 Detail（/companies/:id） | 173 |
| `modules/companies/CompanyDetailTabs.tsx` | 公司 tabs 內容 | 604 |
| `modules/projects/ProjectsDetailPage.tsx` | 專案 Detail（/projects/:id） | 165 |
| `modules/projects/ProjectDetailCalendar.tsx` | 專案 calendar tab | 42 |
| `modules/tasks/TaskDetailPage.tsx` | 任務 Detail（/tasks/:id） | 227 |
| `modules/touchpoints/TouchpointDetailPage.tsx` | Touchpoint Detail（/touchpoints/:id） | 165 |
| `modules/shared/NexusDetailPageV2.tsx` | **共用 desktop detail layout**（header/back/tabs 框架） | 318 |
| `modules/shared/DetailDrawerContent.tsx` | **共用 drawer detail layout** | 435 |
| `modules/GenericDetailPage.tsx` | Generic fallback detail（舊 route） | 456 |
| `pages/DeepLinkEventPage.tsx` | 會議/Event deep link 頁（/l/m/:id） | 170 |
| `pages/IntegrationDetailPage.tsx` | Integration 設定 detail | 353 |

## 調整策略建議
- **大改外觀/結構**：由 `NexusDetailPageV2`（desktop layout）+ `DetailDrawerContent`（drawer）入手 — 改一次全部 detail pages 跟
- **逐 module 改**：改 `*DetailTabs.tsx` 內容
- **Mobile view**：detail pages 有 mobile 分支（media query / 條件 render）— 指出想點改我再落

## 提示
- 直接喺 repo 改（`src/modules/…`）
- 改完 `npm run build` 出 production
- Mobile 實測用 special access link（Hermes 開）
