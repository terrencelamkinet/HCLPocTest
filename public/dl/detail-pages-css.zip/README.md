# Detail Pages — Related CSS（2026-09-06）

> Detail pages 渲染 chain 需要嘅 styles。class 名集中喺 nexus-detail-v2.css，
> 其餘係佢依賴嘅 tokens / shell / override / mobile。

## File 清單（8 files，2,551 行）

| File | 角色 | 行數 |
|---|---|---|
| `nexus-detail-v2.css` | **主 Detail styles**（detail-header/body/tabs/actions — 全部 detail class 定義喺度） | 241 |
| `nexus-modal-tokens.css` | Drawer/modal tokens（DetailDrawerContent 用） | 331 |
| `penguincrm-tokens.css` | **Design tokens**（CSS variables — 全站顏色/間距/圓角定義） | 30 |
| `nexus-module-shell.css` | Module shell layout（detail 頁嘅外殼容器） | 26 |
| `design4-overrides.css` | Design v4 overrides（部分 detail 外觀被 override） | 197 |
| `design4-v2-patch.css` | Design v4 patch（最新 override 層 — 大改前必睇） | 604 |
| `mobile-nav-v3.css` | Mobile nav + detail mobile 分支（bottom nav/sheet/panel） | 667 |
| `nexus-topbar-dashboard-v2.css` | Desktop topbar/shell header | 455 |

## 調整策略
- **Detail 直接外觀**（header/body/tabs）→ `nexus-detail-v2.css`
- **Drawer 外觀** → `nexus-modal-tokens.css`
- **顏色/間距/圓角 token** → `penguincrm-tokens.css`（改一次全站跟）
- **見到設計「唔跟」你嘅改動** → 好可能俾 `design4-overrides.css` / `design4-v2-patch.css` 覆蓋 — 要一齊改
- **Mobile 版面** → `mobile-nav-v3.css`
